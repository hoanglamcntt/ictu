<?php
/**
 * Ovic Template Hooks
 *
 * Action/filter hooks used for Ovic functions/templates.
 *
 * @package Ovic/Templates
 * @version 1.0.0
 */

defined('ABSPATH') || exit;

/**
 *
 * REMOVE RAW CONTENT
 **/
add_filter('get_pagenum_link', function ($result) {
    $result = remove_query_arg('ovic_raw_content', $result);

    return $result;
});
/**
 *
 * WOOCOMMERCE VARIABLE PRODUCT
 */
add_filter('woocommerce_available_variation', 'ovic_custom_available_variation', 10, 3);
/**
 *
 * RESIZE IMAGE
 **/
//add_filter('wp_lazy_loading_enabled', 'ovic_image_lazy_loading', 10, 3);
//add_filter('wp_get_attachment_url', 'ovic_wp_get_attachment_url', 10, 2);
add_filter('wp_kses_allowed_html', 'ovic_wp_kses_allowed_html', 10, 2);
add_filter('wp_get_attachment_image_attributes', 'ovic_lazy_attachment_image', 10, 3);
add_filter('vc_wpb_getimagesize', 'ovic_vc_wpb_getimagesize', 10, 3);
add_filter('post_thumbnail_html', 'ovic_post_thumbnail_html', 10, 5);
add_filter('dokan_product_image_attributes', 'ovic_dokan_image_attributes', 10, 3);
/**
 *
 * BUTTON BUY NOW
 **/
add_filter('woocommerce_add_to_cart_redirect', 'ovic_redirect_cart_buy_now', 10, 2);