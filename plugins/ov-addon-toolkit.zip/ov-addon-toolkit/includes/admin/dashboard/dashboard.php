<?php if (!defined('ABSPATH')) {
    die;
} // Cannot access pages directly.

if (!class_exists('Ovic_Addon_Welcome')) {
    class Ovic_Addon_Welcome {
        public $tabs          = array();
        public $theme;
        public $theme_slug    = '';
        public $theme_root    = '';
        public $theme_name    = '';
        public $theme_version = '';
        public $theme_url     = '';
        public $stylesheet    = array();
        public $verify        = array();
        /* Dashboard */
        public $dashboard_url = '';
        public $dashboard_dir = '';
        /* Token */
        public $token_buy  = '';
        public $token_list = 'sntVqHmrHVU5FGEkESRFHdE45rJs9AIg';

        public function __construct()
        {
            $current_theme       = wp_get_theme(get_template());
            $this->theme_slug    = get_template();
            $this->theme         = $current_theme;
            $this->theme_root    = $current_theme->theme_root . '/' . $this->theme_slug;
            $this->theme_name    = $current_theme->get('Name');
            $this->theme_version = $current_theme->get('Version');
            $this->theme_url     = $current_theme->get('ThemeURI');
            $this->stylesheet    = OVIC_CORE()->get_stylesheet();
            // $this->verify        = OVIC_CORE()->verify_envato();
            /* Dashboard */
            $this->dashboard_url = trailingslashit(plugin_dir_url(__FILE__));
            $this->dashboard_dir = trailingslashit(plugin_dir_path(__FILE__));

            $this->auto_update();

            $this->set_tabs();

            add_action('admin_menu', array($this, 'admin_menu'), 5);
            add_action('admin_enqueue_scripts', array($this, 'dashboard_admin_scripts'), 30);
        }

        public function dashboard_admin_scripts($hook)
        {
            if ($hook == 'toplevel_page_ovic_addon-dashboard') {
                wp_enqueue_style(
                    'ovic-addon-dashboard',
                    $this->dashboard_url . 'assets/dashboard.css',
                    array(),
                    OVIC_VERSION
                );
                wp_enqueue_script(
                    'ovic-addon-dashboard',
                    $this->dashboard_url . 'assets/dashboard.js',
                    array('jquery'),
                    OVIC_VERSION,
                    true
                );
                OVIC::enqueue_scripts();
            }
            if ($hook == 'index.php') {
                wp_enqueue_style(
                    'ovic-widget-dashboard',
                    $this->dashboard_url . 'assets/dashboard-widgets.css',
                    array(),
                    OVIC_VERSION
                );
                wp_enqueue_script(
                    'ovic-widget-dashboard',
                    $this->dashboard_url . 'assets/dashboard-widgets.js',
                    array('jquery'),
                    OVIC_VERSION,
                    true
                );
            }
        }

        public function admin_menu()
        {
            if (current_user_can('edit_theme_options')) {
                add_menu_page(__('Ovic Panel'), __('Ovic Panel'), 'manage_options', 'ovic_addon-dashboard', array($this, 'welcome'), $this->dashboard_url . 'images/icon-menu.png', 2);
            }
        }

        public function auto_update()
        {
            include_once dirname(__FILE__) . '/settings.php';
        }

        public function set_tabs()
        {
            $tabs       = array(
                'dashboard' => esc_html__('Welcome', 'ovic-addon-toolkit'),
                'changelog' => esc_html__('Changelog', 'ovic-addon-toolkit'),
                'settings'  => esc_html__('Settings', 'ovic-addon-toolkit')
            );
            $this->tabs = apply_filters('ovic_registered_dashboard_tabs', $tabs);
        }

        public function welcome()
        {
            $default = isset($_GET['tab']) ? sanitize_key($_GET['tab']) : 'dashboard';
            ?>
            <div class="ovic-addon-dashboard">
                <div id="tabs-container" role="tabpanel">
                    <div class="nav-tab-wrapper">
                        <?php foreach ($this->tabs as $function => $name): ?>
                            <?php
                            $class = 'nav-tab';
                            if ($default === $function) {
                                $class .= ' nav-tab-active';
                            }
                            $url = add_query_arg(array('page' => 'ovic_addon-dashboard', 'tab' => $function,), admin_url('admin.php'));
                            ?>
                            <a class="<?php echo esc_attr($class); ?>" href="<?php echo esc_url($url); ?>" data-tab=".<?php echo esc_attr($function); ?>">
                                <?php echo esc_html($name); ?>
                            </a>
                        <?php endforeach; ?>
                    </div>
                    <div class="tab-content-wrapper">
                        <?php foreach ($this->tabs as $function => $name): ?>
                            <?php
                            $class = 'tab-content ' . $function;
                            if ($default === $function) {
                                $class .= ' active';
                            }
                            ?>
                            <div class="<?php echo esc_attr($class); ?>">
                                <?php
                                ob_start();
                                if (function_exists($function)) {
                                    $function();
                                } elseif (method_exists($this, $function)) {
                                    $this->$function();
                                }
                                $content_tab = ob_get_clean();
                                echo apply_filters('ovic_addon_dashboard_tab_content_' . $function, $content_tab, $function);
                                ?>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
            <?php
        }

        function ovic_let_to_num($size)
        {
            $l   = substr($size, -1);
            $ret = (int)substr($size, 0, -1);
            switch (strtoupper($l)) {
                case 'P':
                    $ret *= 1024;
                // No break.
                case 'T':
                    $ret *= 1024;
                // No break.
                case 'G':
                    $ret *= 1024;
                // No break.
                case 'M':
                    $ret *= 1024;
                // No break.
                case 'K':
                    $ret *= 1024;
                // No break.
            }
            return $ret;
        }

        public function dashboard()
        {
            $wp_memory_limit = $this->ovic_let_to_num(WP_MEMORY_LIMIT);
            if (function_exists('memory_get_usage')) {
                $wp_memory_limit = max($wp_memory_limit, $this->ovic_let_to_num(@ini_get('memory_limit'))); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
            }

            $environment  = array(
                'home_url'              => get_option('home'),
                'site_url'              => get_option('siteurl'),
                'wp_version'            => get_bloginfo('version'),
                'wp_multisite'          => is_multisite(),
                'wp_memory_limit'       => $wp_memory_limit,
                'wp_debug_mode'         => (defined('WP_DEBUG') && WP_DEBUG),
                'wp_cron'               => !(defined('DISABLE_WP_CRON') && DISABLE_WP_CRON),
                'language'              => get_locale(),
                'external_object_cache' => wp_using_ext_object_cache(),
            );
            $active_theme = wp_get_theme();
            $security     = array(
                'secure_connection' => 'https' === substr(get_home_url(), 0, 5),
                'hide_errors'       => !(defined('WP_DEBUG') && defined('WP_DEBUG_DISPLAY') && WP_DEBUG && WP_DEBUG_DISPLAY) || 0 === intval(ini_get('display_errors')),
            );
            ?>
            <div class="dashboard">
                <div class="theme-thumbnail">
                    <img src="<?php echo esc_url(wp_get_theme()->get_screenshot()); ?>" alt="<?php echo esc_attr($this->theme_name); ?>">
                </div>
                <div class="theme-intro">
                    <h1 class="theme-name-text">Welcome to <?php echo ucfirst(esc_html($this->theme_name)); ?> - Version <?php echo esc_html($this->theme_version); ?></h1>
                    <table class="hdtn_status_table widefat" cellspacing="0">
                        <thead>
                        <tr>
                            <th colspan="3" data-export-label="Theme"><h2>Giao diện</h2></th>
                        </tr>
                        </thead>
                        <tbody>
                        <tr>
                            <td data-export-label="Name">Tên:</td>
                            <td><?php echo esc_html($active_theme->name); ?></td>
                        </tr>
                        <tr>
                            <td data-export-label="Version">Phiên bản:</td>
                            <td><?php echo esc_html($active_theme->version) ?></td>
                        </tr>
                        <tr>
                            <td data-export-label="Author URL">URL tác giả:</td>
                            <td><?php echo esc_url_raw($active_theme->{'Author URI'}); ?></td>
                        </tr>
                    </table>

                    <table class="hdtn_status_table widefat" cellspacing="0">
                        <thead>
                        <tr>
                            <th colspan="3"><h2>Môi trường WordPress</h2></th>
                        </tr>
                        </thead>
                        <tbody>
                        <tr>
                            <td>Địa chỉ WordPress (URL):</td>
                            <td><?php echo esc_html($environment['site_url']); ?></td>
                        </tr>
                        <tr>
                            <td>Địa chỉ trang web (URL):</td>
                            <td><?php echo esc_html($environment['home_url']); ?></td>
                        </tr>
                        <tr>
                            <td>Phiên bản WordPress:</td>
                            <td>
                                <mark class="yes"> <?php echo esc_html($environment['wp_version']); ?></mark>
                            </td>
                        </tr>
                        <tr>
                            <td>WordPress multiside:</td>
                            <td><?php echo ($environment['wp_multisite']) ? '<span class="dashicons dashicons-yes"></span>' : '&ndash;'; ?></td>
                        </tr>
                        <tr>
                            <td>Giới hạn bộ nhớ WordPress:</td>
                            <td>
                                <?php
                                if ($environment['wp_memory_limit'] < 67108864) {
                                    /* Translators: %1$s: Memory limit, %2$s: Docs link. */
                                    echo '<mark class="error"><span class="dashicons dashicons-warning"></span> ' . sprintf('%1$s - Chúng tôi khuyến nghị bộ nhớ cài đặt ít nhất là 64MB. Tham khoải thêm: %2$s', esc_html(size_format($environment['wp_memory_limit'])), '<a href="https://wordpress.org/support/article/editing-wp-config-php/#increasing-memory-allocated-to-php" target="_blank">Tăng bộ nhớ được phân bổ cho PHP</a>') . '</mark>';
                                } else {
                                    echo '<mark class="yes">' . esc_html(size_format($environment['wp_memory_limit'])) . '</mark>';
                                }
                                ?>
                            </td>
                        </tr>
                        <tr>
                            <td>Chế độ gỡ lỗi WordPress:</td>
                            <td>
                                <?php if ($environment['wp_debug_mode']) : ?>
                                    <mark class="yes"><span class="dashicons dashicons-yes"></span></mark>
                                <?php else : ?>
                                    <mark class="no">&ndash;</mark>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <tr>
                            <!--Displays whether or not WP Cron Jobs are enabled.-->
                            <td>WordPress cron:</td>
                            <td>
                                <?php if ($environment['wp_cron']) : ?>
                                    <mark class="yes"><span class="dashicons dashicons-yes"></span></mark>
                                <?php else : ?>
                                    <mark class="no">&ndash;</mark>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <tr>
                            <td>Ngôn ngữ:</td>
                            <td><?php echo esc_html($environment['language']); ?></td>
                        </tr>
                        <tr>
                            <!--Displays whether or not WordPress is using an external object cache.-->
                            <td>External object cache:</td>
                            <td>
                                <?php if ($environment['external_object_cache']) : ?>
                                    <mark class="yes"><span class="dashicons dashicons-yes"></span></mark>
                                <?php else : ?>
                                    <mark class="no">&ndash;</mark>
                                <?php endif; ?>
                            </td>
                        </tr>
                        </tbody>
                    </table>

                    <table class="hdtn_status_table widefat" cellspacing="0">
                        <thead>
                        <tr>
                            <th colspan="3"><h2>Bảo mật</h2></th>
                        </tr>
                        </thead>
                        <tbody>
                        <tr>
                            <td>Kết nối bảo mật (HTTPS):</td>
                            <td>
                                <?php if ($security['secure_connection']) : ?>
                                    <mark class="yes"><span class="dashicons dashicons-yes"></span></mark>
                                <?php else : ?>
                                    <mark class="error"><span class="dashicons dashicons-warning"></span>
                                        Trang web của bạn không sử dụng giao thức an toàn HTTPS.
                                        <a href="https://docs.woocommerce.com/document/ssl-and-https/" target="_blank">Tìm hiểu thêm về chứng chỉ bảo mật HTTPS và SSL</a>
                                    </mark>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <tr>
                            <td>Ẩn lỗi khỏi người xem</td>
                            <td>
                                <?php if ($security['hide_errors']) : ?>
                                    <mark class="yes"><span class="dashicons dashicons-yes"></span></mark>
                                <?php else : ?>
                                    <mark class="error">
                                        <span class="dashicons dashicons-warning"></span> Thông báo lỗi không nên hiển thị tới người dùng
                                    </mark>
                                <?php endif; ?>
                            </td>
                        </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <?php
        }

        public function license()
        {
            ?>
            <div id="dashboard-license" class="dashboard-license tab-panel">
                <?php do_action('ovic_license_' . $this->theme_slug . '_page'); ?>
            </div>
            <?php
        }

        public function envato_license()
        {
            // do_action('ovic_envato_license');
        }

        public function our_theme()
        {
        }

        public function changelog()
        {
            if (file_exists(get_template_directory() . '/changelog.txt')) {
                $changelog = file_get_contents(get_template_directory() . '/changelog.txt');
                echo '<pre class="changelog">';
                print_r($changelog);
                echo '</pre>';
            } else {
                echo '<pre class="changelog">';
                print_r('No Change Log Found!');
                echo '</pre>';
            }
        }

        public function settings()
        {
            do_action('ovic_addon_settings');
        }
    }

    new Ovic_Addon_Welcome();
}